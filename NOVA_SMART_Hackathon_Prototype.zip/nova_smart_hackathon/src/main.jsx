import React, {useMemo, useState} from "react";
import {createRoot} from "react-dom/client";
import {Search, ShoppingCart, MapPin, Sparkles, ShieldCheck, Store, BarChart3, Package, Truck, AlertTriangle, RefreshCw, ChevronRight, CheckCircle2, Clock3, Zap, SlidersHorizontal, X} from "lucide-react";
import {LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar} from "recharts";
import "./styles.css";

const products = [
  {id:1,name:"Amul Taaza Milk 1L",cat:"Dairy",price:68,store:"Sri Lakshmi Stores",distance:1.1,eta:32,confidence:41,updated:"17h ago",risk:82},
  {id:2,name:"Heritage Milk 1L",cat:"Dairy",price:70,store:"Sai Local Mart",distance:1.4,eta:23,confidence:94,updated:"18 min ago",risk:12},
  {id:3,name:"Aashirvaad Atta 5kg",cat:"Groceries",price:315,store:"City Fresh",distance:1.8,eta:28,confidence:91,updated:"32 min ago",risk:18},
  {id:4,name:"Brown Bread",cat:"Bakery",price:45,store:"Bake Corner",distance:0.9,eta:18,confidence:76,updated:"41 min ago",risk:37},
  {id:5,name:"Farm Eggs 12 pack",cat:"Dairy",price:92,store:"Sri Lakshmi Stores",distance:1.1,eta:29,confidence:88,updated:"24 min ago",risk:22},
  {id:6,name:"Classmate Notebook",cat:"Stationery",price:65,store:"Campus Needs",distance:2.2,eta:35,confidence:97,updated:"12 min ago",risk:8}
];

const stores = [
  {name:"Sri Lakshmi Stores",orders:27,low:8,rejected:1,mode:"Normal"},
  {name:"Sai Local Mart",orders:34,low:4,rejected:0,mode:"Normal"},
  {name:"City Fresh",orders:21,low:6,rejected:2,mode:"Busy"}
];

const trend = [
  {m:"Apr", repeat:41, cancel:6, delivery:29},
  {m:"May", repeat:38, cancel:7, delivery:30},
  {m:"Jun", repeat:35, cancel:8, delivery:32},
  {m:"Jul", repeat:32, cancel:9, delivery:34},
  {m:"Aug", repeat:29, cancel:10, delivery:36},
  {m:"Sep", repeat:27, cancel:11, delivery:37}
];

function App(){
  const [role,setRole]=useState("customer");
  const [page,setPage]=useState("home");
  const [query,setQuery]=useState("");
  const [cart,setCart]=useState([]);
  const [ordered,setOrdered]=useState(false);
  const [inventory,setInventory]=useState(4);
  const [riskReduction,setRiskReduction]=useState(20);
  const [toast,setToast]=useState("");

  const showToast=(m)=>{setToast(m);setTimeout(()=>setToast(""),2400)}
  const searchResults=useMemo(()=>{
    const q=query.trim().toLowerCase();
    if(!q) return products;
    return products.filter(p=>(p.name+" "+p.cat+" "+p.store).toLowerCase().includes(q));
  },[query]);

  const add=(p)=>{setCart([...cart,p]);showToast(`${p.name} added to cart`)}
  const avoided=Math.round(38500*0.11*0.35*(riskReduction/100));
  const recoveredGMV=avoided*486;

  const switchRole=(r)=>{
    setRole(r);
    setPage(r==="customer"?"home":r==="store"?"storeDash":"admin");
  }

  return <div className="app">
    <header className="topbar">
      <div className="brand" onClick={()=>{setRole("customer");setPage("home")}}>
        <div className="brandmark"><Sparkles size={18}/></div>
        <div><b>NOVA SMART</b><span>Local Commerce Rescue</span></div>
      </div>
      <div className="demo-switch">
        <button className={role==="customer"?"active":""} onClick={()=>switchRole("customer")}>Customer</button>
        <button className={role==="store"?"active":""} onClick={()=>switchRole("store")}>Store</button>
        <button className={role==="admin"?"active":""} onClick={()=>switchRole("admin")}>Admin</button>
      </div>
      <div className="top-actions">
        <span><MapPin size={15}/> Visakhapatnam</span>
        {role==="customer" && <button className="cart-btn" onClick={()=>setPage("cart")}><ShoppingCart size={17}/> {cart.length}</button>}
      </div>
    </header>

    {role==="customer" && <Customer page={page} setPage={setPage} query={query} setQuery={setQuery} results={searchResults} add={add} cart={cart} setCart={setCart} ordered={ordered} setOrdered={setOrdered} showToast={showToast}/>}
    {role==="store" && <StoreDashboard inventory={inventory} setInventory={setInventory} showToast={showToast}/>}
    {role==="admin" && <AdminDashboard riskReduction={riskReduction} setRiskReduction={setRiskReduction} avoided={avoided} recoveredGMV={recoveredGMV}/>}

    {toast && <div className="toast"><CheckCircle2 size={17}/>{toast}</div>}
    <footer>Hackathon prototype • Decision-support logic uses transparent demo data • No paid APIs required</footer>
  </div>
}

function Customer({page,setPage,query,setQuery,results,add,cart,setCart,ordered,setOrdered,showToast}){
  if(page==="cart") return <Cart cart={cart} setCart={setCart} setPage={setPage} ordered={ordered} setOrdered={setOrdered} showToast={showToast}/>;
  if(page==="orders") return <Orders ordered={ordered}/>;
  return <main>
    <section className="hero">
      <div>
        <div className="eyebrow"><Sparkles size={14}/> AI-powered local commerce</div>
        <h1>Predict the problem<br/><span>before the order fails.</span></h1>
        <p>NOVA SMART connects customers, local stores and operations to reduce stockout-driven cancellations and make local commerce more reliable.</p>
        <div className="search"><Search size={20}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search Milk, Rice, Bread, Notebook…"/>{query && <button onClick={()=>setQuery("")}><X size={17}/></button>}</div>
        <div className="quick"><button onClick={()=>setQuery("Milk")}>Try “Milk”</button><button onClick={()=>setQuery("Bread")}>Bread</button><button onClick={()=>setQuery("Notebook")}>Notebook</button></div>
      </div>
      <div className="hero-card">
        <div className="mini-label">LIVE DEMO</div>
        <h3>Order Health</h3>
        <div className="health"><span className="dot green"></span> Products likely available <b>94%</b></div>
        <div className="health"><span className="dot green"></span> Store accepting orders <b>✓</b></div>
        <div className="health"><span className="dot green"></span> Delivery confidence <b>91%</b></div>
        <div className="health-total">Cancellation risk <strong>LOW</strong></div>
      </div>
    </section>

    <section className="section">
      <div className="section-head"><div><div className="eyebrow">SMART AVAILABILITY</div><h2>Find what is actually likely to be available.</h2></div><button className="ghost" onClick={()=>setPage("orders")}>My orders <ChevronRight size={16}/></button></div>
      <div className="product-grid">
        {results.map(p=><ProductCard key={p.id} p={p} add={add}/>)}
      </div>
      {!results.length && <div className="empty">No products found. Try “Milk” to see the main demo.</div>}
    </section>

    <section className="problem-strip">
      <div><b>Why NOVA SMART?</b><span>Current cancellation rate</span><strong>11%</strong></div>
      <div><span>Share attributed to unavailable products</span><strong>35%</strong></div>
      <div><span>Repeat purchase rate</span><strong>27%</strong></div>
      <div><span>Support tickets / month</span><strong>5,900</strong></div>
    </section>

    <section className="section two">
      <div className="explain">
        <div className="eyebrow">THE INSIGHT</div>
        <h2>Turn the local-store network into an advantage.</h2>
        <p>Instead of showing a product as simply “in stock”, NOVA SMART estimates availability confidence using inventory freshness, historical availability and stock risk.</p>
        <div className="chain">
          <span>Outdated inventory</span><i>→</i><span>Stockout</span><i>→</i><span>Cancellation</span><i>→</i><span>Refund / support</span>
        </div>
      </div>
      <div className="feature-list">
        <div><ShieldCheck/><div><b>Pre-order Risk Check</b><p>Catch risky orders before checkout.</p></div></div>
        <div><RefreshCw/><div><b>Smart Alternatives</b><p>Recommend a nearby option instead of saying “out of stock”.</p></div></div>
        <div><Zap/><div><b>Store-side Action</b><p>Make stock updates fast enough for busy local retailers.</p></div></div>
      </div>
    </section>
  </main>
}

function ProductCard({p,add}){
  const good=p.confidence>=75;
  return <div className="product-card">
    <div className="product-icon">{p.cat==="Dairy"?"🥛":p.cat==="Bakery"?"🍞":p.cat==="Stationery"?"📓":"🛒"}</div>
    <div className="product-info"><div className="tag">{p.cat}</div><h3>{p.name}</h3><p><Store size={14}/> {p.store} · {p.distance} km</p></div>
    <div className="price">₹{p.price}</div>
    <div className="confidence"><div><span>AI availability confidence</span><b>{p.confidence}%</b></div><div className="bar"><i style={{width:p.confidence+"%"}}/></div><small>{p.updated} · {p.eta} min ETA</small></div>
    <div className="card-actions">{p.confidence<60 && <button className="recommend">⚡ Alternative available</button>}<button className="primary" onClick={()=>add(p)}>Add</button></div>
  </div>
}

function Cart({cart,setCart,setPage,ordered,setOrdered,showToast}){
  const [risk,setRisk]=useState(false);
  const total=cart.reduce((s,p)=>s+p.price,0);
  if(ordered) return <main className="center-page"><div className="success-card"><div className="success-icon"><CheckCircle2 size={42}/></div><div className="eyebrow">ORDER CONFIRMED</div><h1>Order #NS-2048</h1><p>Your order is being prepared by <b>{cart[0]?.store||"Sai Local Mart"}</b>.</p><div className="order-health"><b>Delivery confidence 91%</b><span>Estimated arrival: 23–27 min</span></div><button className="primary big" onClick={()=>setPage("orders")}>Track order</button></div></main>
  return <main className="section narrow">
    <div className="section-head"><div><div className="eyebrow">CHECKOUT</div><h1>Your cart</h1></div><button className="ghost" onClick={()=>setPage("home")}>Continue shopping</button></div>
    {!cart.length ? <div className="empty">Your cart is empty. Search for Milk to start the demo.</div> :
    <div className="checkout">
      <div className="cart-items">{cart.map((p,i)=><div className="cart-row" key={i}><span>{p.name}</span><b>₹{p.price}</b></div>)}</div>
      <div className="risk-check">
        <h3><ShieldCheck/> Pre-order Risk Check</h3>
        {!risk ? <><p>We check availability, store status and delivery risk before placing your order.</p><button className="primary big" onClick={()=>setRisk(true)}>Run risk check</button></> :
        <><div className="risk-line"><CheckCircle2/> Products likely available <b>94%</b></div><div className="risk-line"><CheckCircle2/> Store accepting orders <b>YES</b></div><div className="risk-line"><CheckCircle2/> Delivery confidence <b>91%</b></div><div className="risk-total">Cancellation risk <strong>LOW</strong></div><button className="primary big" onClick={()=>{setOrdered(true);showToast("Order placed successfully")}}>Place order · ₹{total}</button></>}
      </div>
    </div>}
  </main>
}

function Orders({ordered}){return <main className="section narrow"><div className="eyebrow">CUSTOMER</div><h1>Order tracking</h1><div className="tracking"><div className="track-top"><b>Order #NS-2048</b><span className="pill">ETA 23–27 min</span></div>{["Order placed","Store confirmed","Preparing","Picked up","Out for delivery","Delivered"].map((x,i)=><div className={"track-step "+(i<4?"done":"")} key={x}><div className="track-dot">{i<4?"✓":i+1}</div><div><b>{x}</b><small>{i<4?"Completed":"Upcoming"}</small></div></div>)}</div></main>}

function StoreDashboard({inventory,setInventory,showToast}){
  const high=inventory<6;
  return <main className="dashboard">
    <div className="dash-head"><div><div className="eyebrow">STORE PARTNER</div><h1>Sri Lakshmi Stores</h1><p>Turn inventory updates into fewer failed orders.</p></div><button className="primary" onClick={()=>showToast("Store status updated")}>Store is open</button></div>
    <div className="kpis"><Kpi icon={<Package/>} label="Today's orders" value="27"/><Kpi icon={<AlertTriangle/>} label="Low-stock items" value="8" danger/><Kpi icon={<Truck/>} label="Rejected orders" value="1"/><Kpi icon={<Zap/>} label="Stockout risk" value={high?"HIGH":"LOW"} danger={high}/></div>
    <div className="dash-grid">
      <div className="panel"><div className="panel-head"><div><div className="eyebrow">AI STOCK RISK</div><h2>What needs attention?</h2></div><button className="ghost"><SlidersHorizontal size={15}/> Filter</button></div>
        {[{n:"Amul Taaza Milk 1L",stock:inventory,risk:high?87:12},{n:"Brown Bread",stock:3,risk:63},{n:"Farm Eggs 12 pack",stock:9,risk:22}].map((x,i)=><div className="stock-row" key={x.n}><div className="stock-emoji">{i===0?"🥛":i===1?"🍞":"🥚"}</div><div className="stock-name"><b>{x.n}</b><span>{x.stock} units · updated 18 min ago</span></div><div className="risk"><b>{x.risk}%</b><span>risk</span></div><button className="small" onClick={()=>{setInventory(i===0?20:x.stock+5);showToast("Inventory updated")}}>Update stock</button></div>)}
      </div>
      <div className="panel insight-panel"><div className="eyebrow">AI EXPLANATION</div><h2>Why is Milk risky?</h2><p>Inventory freshness and sales velocity indicate a high stockout probability when the available quantity is low.</p><div className="reason"><b>Recommended action</b><span>Confirm current stock before accepting more orders.</span></div><button className="primary" onClick={()=>{setInventory(20);showToast("Milk stock confirmed: 20 units")}}>Confirm Milk stock</button></div>
    </div>
    <div className="panel inventory-panel"><div className="panel-head"><div><div className="eyebrow">INVENTORY</div><h2>Simple stock control</h2></div></div><table><thead><tr><th>Product</th><th>Stock</th><th>Last updated</th><th>Availability confidence</th><th>Action</th></tr></thead><tbody>{products.slice(0,4).map((p,i)=><tr key={p.id}><td><b>{p.name}</b></td><td>{i===0?inventory:[8,18,35][i-1]}</td><td>{i===0?"18 min ago":p.updated}</td><td><span className={"status "+(i===0&&inventory<6?"bad":"good")}>{i===0&&inventory<6?"42%":"94%"}</span></td><td><button className="small" onClick={()=>showToast("Availability confirmed")}>Confirm</button></td></tr>)}</tbody></table></div>
  </main>
}

function Kpi({icon,label,value,danger}){return <div className="kpi"><div className="kpi-icon">{icon}</div><span>{label}</span><strong className={danger?"danger":""}>{value}</strong></div>}

function AdminDashboard({riskReduction,setRiskReduction,avoided,recoveredGMV}){
  return <main className="dashboard">
    <div className="dash-head"><div><div className="eyebrow">ADMIN · BUSINESS COMMAND CENTER</div><h1>NOVA SMART</h1><p>Decision support for the quality and cost of growth.</p></div><span className="live"><i/> Demo data connected</span></div>
    <div className="kpis six"><Kpi label="Monthly revenue" value="₹26.1L" icon={<BarChart3/>}/><Kpi label="Repeat purchase" value="27%" icon={<RefreshCw/>} danger/><Kpi label="Cancellation" value="11%" icon={<AlertTriangle/>} danger/><Kpi label="Avg delivery" value="37 min" icon={<Truck/>}/><Kpi label="Support tickets" value="5,900" icon={<ShieldCheck/>}/><Kpi label="Promo spend" value="₹17L" icon={<Zap/>}/></div>
    <div className="dash-grid charts">
      <div className="panel chart-panel"><div className="panel-head"><div><div className="eyebrow">CUSTOMER HEALTH</div><h2>Repeat vs cancellation</h2></div></div><ResponsiveContainer width="100%" height={250}><LineChart data={trend}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="m"/><YAxis/><Tooltip/><Line type="monotone" dataKey="repeat" strokeWidth={3} name="Repeat %"/><Line type="monotone" dataKey="cancel" strokeWidth={3} name="Cancel %"/></LineChart></ResponsiveContainer></div>
      <div className="panel chart-panel"><div className="panel-head"><div><div className="eyebrow">OPERATIONS</div><h2>Delivery time</h2></div></div><ResponsiveContainer width="100%" height={250}><BarChart data={trend}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="m"/><YAxis/><Tooltip/><Bar dataKey="delivery" name="Minutes"/></BarChart></ResponsiveContainer></div>
    </div>
    <div className="dash-grid">
      <div className="panel ai-panel"><div className="eyebrow">AI BUSINESS INSIGHT</div><h2>Inventory accuracy deserves attention.</h2><p><b>Evidence:</b> 35% of cancellations are attributed to unavailable products, while partner stores report that maintaining online inventory requires too much effort.</p><div className="ai-action"><b>Recommended intervention</b><span>Inventory freshness + availability confidence + smart alternatives.</span></div><div className="impact-line"><span>Potential value</span><b>Fewer avoidable cancellations, refunds and support interactions.</b></div></div>
      <div className="panel simulator"><div className="eyebrow">BUSINESS IMPACT SIMULATOR</div><h2>Test a scenario</h2><p>Illustrative only — not a forecast.</p><label>Reduction in inventory-related cancellations <b>{riskReduction}%</b></label><input type="range" min="0" max="50" value={riskReduction} onChange={e=>setRiskReduction(+e.target.value)}/><div className="sim-results"><div><span>Avoided cancellations</span><b>{avoided.toLocaleString()}</b></div><div><span>Recovered orders</span><b>{avoided.toLocaleString()}</b></div><div><span>Potential GMV</span><b>₹{recoveredGMV.toLocaleString()}</b></div></div></div>
    </div>
    <div className="panel"><div className="eyebrow">THE STORY</div><div className="story"><span>Evidence</span><i>→</i><span>Insight</span><i>→</i><span>AI decision</span><i>→</i><span>Store action</span><i>→</i><span>Business impact</span></div></div>
  </main>
}

createRoot(document.getElementById("root")).render(<App/>);
